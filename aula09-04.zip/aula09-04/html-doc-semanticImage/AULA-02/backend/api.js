const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extend: false }));
app.use(bodyParser.json());

app.post('/contato' , (req, res) => {
    const {nome, email, telefone, mensagem } = req.body;
    console.log('Nome', nome);
    console.log('Email', email);
    console.log('Telefone', telefone);
    console.log('Mensagem', mensagem);

    res.send('Recebi seus dados, aguarde nosso retorno')
});

app.listen(port, () => {
    console.log(`estou ouvindo na porta ${port}`)
})